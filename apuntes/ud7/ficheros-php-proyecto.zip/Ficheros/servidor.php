<?php
	//header('Content-type: application/json; charset=utf-8');

	echo '{ "employees" : [' .
			'{ "firstName":"John" , "lastName":"Doe" },' .	
			'{ "firstName":"Anna" , "lastName":"Smith" },' .
			'{ "firstName":"Peter" , "lastName":"Jones" } ]}' 

?>